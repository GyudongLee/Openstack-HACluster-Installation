PANEL_GROUP = 'rating'
PANEL_DASHBOARD = 'admin'
PANEL = 'pyscripts'

ADD_PANEL = 'cloudkittydashboard.dashboards.admin.pyscripts.panel.PyScripts'
