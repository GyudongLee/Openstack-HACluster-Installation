#!/bin/bash

# 에러 페이지를 저장할 디렉터리
ERROR_DIR="/etc/haproxy/errors"

# 디렉터리가 없으면 생성
if [ ! -d "$ERROR_DIR" ]; then
    mkdir -p "$ERROR_DIR"
    echo "Created directory $ERROR_DIR"
fi

# HAProxy가 접근할 수 있도록 디렉터리 소유자 및 권한 설정
chown -R haproxy:haproxy "$ERROR_DIR"
chmod -R 755 "$ERROR_DIR"
echo "Set ownership and permissions for $ERROR_DIR"

# 상태 코드와 대응하는 에러 메시지
declare -A error_messages=(
    [400]="HTTP/1.1 400 Bad Request\r\nContent-Type: text/html\r\n\r\n<h1>400 Bad Request</h1>"
    [403]="HTTP/1.1 403 Forbidden\r\nContent-Type: text/html\r\n\r\n<h1>403 Forbidden</h1>"
    [408]="HTTP/1.1 408 Request Timeout\r\nContent-Type: text/html\r\n\r\n<h1>408 Request Timeout</h1>"
    [500]="HTTP/1.1 500 Internal Server Error\r\nContent-Type: text/html\r\n\r\n<h1>500 Internal Server Error</h1>"
    [502]="HTTP/1.1 502 Bad Gateway\r\nContent-Type: text/html\r\n\r\n<h1>502 Bad Gateway</h1>"
    [503]="HTTP/1.1 503 Service Unavailable\r\nContent-Type: text/html\r\n\r\n<h1>503 Service Unavailable</h1>"
    [504]="HTTP/1.1 504 Gateway Timeout\r\nContent-Type: text/html\r\n\r\n<h1>504 Gateway Timeout</h1>"
)

# 각 상태 코드에 대한 파일 생성
for code in "${!error_messages[@]}"; do
    echo -e "${error_messages[$code]}" > "$ERROR_DIR/$code.http"
    echo "Created $ERROR_DIR/$code.http"
done

echo "All error files have been created in $ERROR_DIR and permissions have been set."
