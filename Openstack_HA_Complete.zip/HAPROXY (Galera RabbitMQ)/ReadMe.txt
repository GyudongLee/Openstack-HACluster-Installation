CreateSH은 각 HAproxy노드에서 전부 돌려주어야 한다. ErrorCode에 관한 파일 생성 방식이다. 
